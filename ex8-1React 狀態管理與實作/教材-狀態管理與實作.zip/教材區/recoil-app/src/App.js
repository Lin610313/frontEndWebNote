import React from 'react';
import logo from './logo.svg';
import './App.css';

import {
  atom,
  useRecoilState
} from 'recoil'

const HelloMsg = atom({
  key: 'helloMsg',
  default: 'Learn React'
})

function Other() {
  const [msg, setMsg] = useRecoilState(HelloMsg)
  return <div>{msg}</div>
}

function App() {
  const [msg, setMsg] = useRecoilState(HelloMsg)
  return (
    <div className="App">
      <Other />
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          {msg}
        </a>
      </header>
    </div>
  );
}

export default App;
