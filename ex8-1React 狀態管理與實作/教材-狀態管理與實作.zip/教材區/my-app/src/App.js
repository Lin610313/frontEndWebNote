import React from 'react';
import logo from './logo.svg';
import './App.css';
import TodoList from './TodoList'
import OtherList from './OtherList'
import { TodosContext } from './Context/Todos'


function App() {
  const handleComplete = (index) => {
    const newTodos = todos.map((todo, index2) => {
    if (index === index2) {
      return {
        ...todo,
        completed: !todo.completed
      }
    }
    return todo
  })
    setTodos(newTodos)
  }
  const [todos, setTodos] = React.useState([
    { title: '吃飯', completed: true },
    { title: '跑步', completed: false }
  ])

  return (
    <TodosContext.Provider value={{
      todos,
      handleComplete 
    }}>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <TodoList />
          <OtherList />
        </header>
      </div>
    </TodosContext.Provider>
  );
}

export default App;
