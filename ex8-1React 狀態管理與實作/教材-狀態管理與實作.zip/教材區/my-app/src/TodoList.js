import React from 'react'
import {TodosContext} from './Context/Todos'

const TodoList = () => {
  const { todos, handleComplete } = React.useContext(TodosContext)
  return <div>
    <h1>My Todo List</h1>
    <ul>
    {
      todos.map((todo, index) => {
      return <li onClick={() => {
        handleComplete(index)
      }}>{todo.title}{todo.completed ? '✅' : '尚未完成'}</li>
      })
    }
    </ul>
  </div>
}

export default TodoList