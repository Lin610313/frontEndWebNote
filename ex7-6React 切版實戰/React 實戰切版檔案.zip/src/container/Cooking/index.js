import React from 'react'

const Cooking = () => {
  return <h1>Welcome Cooking</h1>
}

export default Cooking